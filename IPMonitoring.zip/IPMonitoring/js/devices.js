// devices.js

let allDevices = [];

async function loadDevices() {
    const data = await fetchAPI('/devices.asp');
    if (data && !data.error) {
        allDevices = data.devices;
        renderDevices(allDevices);
    }
}

function filterDevices() {
    const searchTerm = document.getElementById('device-search').value.toLowerCase();
    const statusFilter = document.getElementById('device-filter').value;
    
    const filtered = allDevices.filter(device => {
        // Status check
        if (statusFilter !== 'ALL' && device.status !== statusFilter) {
            return false;
        }
        // Search term check
        if (searchTerm) {
            const matchName = device.name.toLowerCase().includes(searchTerm);
            const matchIp = device.ip_address.toLowerCase().includes(searchTerm);
            if (!matchName && !matchIp) return false;
        }
        return true;
    });
    
    renderDevices(filtered);
}

function renderDevices(devicesArray) {
    const tbody = document.getElementById('devices-body');
    tbody.innerHTML = '';
    
    if(devicesArray.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No devices found.</td></tr>';
        return;
    }
    
    devicesArray.forEach(device => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${device.id}</td>
            <td>${device.name}</td>
            <td>${device.ip_address}</td>
            <td><span class="status-badge ${device.status.toLowerCase()}">${device.status}</span></td>
            <td>${device.last_checked || 'Never'}</td>
            <td>
                <button class="btn btn-primary" onclick="pingDevice(${device.id})">PING NOW</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

async function pingDevice(id) {
    const res = await fetchAPI('/device_ping.asp', 'POST', { device_id: id });
    if (res.success) {
        alert(`Ping successful!\nStatus: ${res.status}\nTime: ${res.responseTime !== null ? res.responseTime : 'null'} ms`);
        loadDevices(); // Refresh list to get latest status
    } else {
        alert('Ping failed: ' + (res.message || 'Unknown error'));
    }
}

function showAddDeviceModal() {
    const name = prompt("Enter device name:");
    if (!name) return;
    const ip = prompt("Enter device IP address:");
    if (!ip) return;
    
    addDevice(name, ip);
}

async function addDevice(name, ip) {
    const res = await fetchAPI('/devices_add.asp', 'POST', { name: name, ip_address: ip });
    if (res.success) {
        loadDevices();
    } else {
        alert('Failed to add device: ' + (res.message || 'Unknown error'));
    }
}
