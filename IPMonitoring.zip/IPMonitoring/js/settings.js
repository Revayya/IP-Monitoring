// settings.js

async function loadSettings() {
    const data = await fetchAPI('/settings.asp');
    if (data && data.settings) {
        document.getElementById('ping_interval').value = data.settings.ping_interval || '60';
        document.getElementById('timeout').value = data.settings.timeout || '1000';
        document.getElementById('retry_count').value = data.settings.retry_count || '3';
        document.getElementById('offline_threshold').value = data.settings.offline_threshold || '3';
        document.getElementById('max_devices_per_cycle').value = data.settings.max_devices_per_cycle || '50';
        document.getElementById('log_retention_days').value = data.settings.log_retention_days || '30';
    }
}

async function saveSettings(event) {
    event.preventDefault();
    
    const settingsData = {
        ping_interval: document.getElementById('ping_interval').value,
        timeout: document.getElementById('timeout').value,
        retry_count: document.getElementById('retry_count').value,
        offline_threshold: document.getElementById('offline_threshold').value,
        max_devices_per_cycle: document.getElementById('max_devices_per_cycle').value,
        log_retention_days: document.getElementById('log_retention_days').value
    };
    
    const res = await fetchAPI('/settings_save.asp', 'POST', settingsData);
    if (res.success) {
        alert('Settings saved successfully!');
    } else {
        alert('Failed to save settings: ' + (res.message || 'Unknown error'));
    }
}
