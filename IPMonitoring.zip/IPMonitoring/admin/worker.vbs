' worker.vbs
' Run this script via Windows Task Scheduler every 1 minute.
' It will hit a dedicated internal ASP page or do direct DB operations.
' Since the prompt asked for "Server-side monitoring process/job" that uses Classic ASP/Windows.
' The easiest is to use a VBScript run by CScript or Task Scheduler to request the monitoring page.

Dim xmlHttp
Set xmlHttp = CreateObject("MSXML2.ServerXMLHTTP.6.0")
xmlHttp.Open "GET", "http://localhost/IPMonitoring/api/worker_ping_cycle.asp", False
xmlHttp.Send

' We assume worker_ping_cycle.asp does the actual database checks and pings.
WScript.Echo "Cycle triggered"
