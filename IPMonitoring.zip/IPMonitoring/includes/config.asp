<%
' Configuration Settings
Dim DB_SERVER, DB_NAME, DB_USER, DB_PASS, DB_PORT, DB_DRIVER

DB_SERVER = "localhost"
DB_NAME   = "ip_monitoring_system"
DB_USER   = "root"
DB_PASS   = ""
DB_PORT   = "3306"
DB_DRIVER = "MySQL ODBC 5.1 Driver"
%>
