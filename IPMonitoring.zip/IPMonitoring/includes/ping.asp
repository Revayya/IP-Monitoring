<%
' Server-side Ping Functionality using WMI
' This avoids IIS permissions issues with executing WScript.Shell and ping.exe

Function PingIP(ipAddress, ByRef outResponseTime, ByRef outStatus)
    Dim objWMIService, colPings, objPing
    
    outResponseTime = Null
    outStatus = "ERROR"
    
    If Not IsValidIP(ipAddress) Then
        Exit Function
    End If
    
    ' Connect to WMI service
    On Error Resume Next
    Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
    Set colPings = objWMIService.ExecQuery("Select * From Win32_PingStatus where Address = '" & Replace(ipAddress, "'", "") & "'")
    
    If Err.Number = 0 Then
        For Each objPing in colPings
            If IsNull(objPing.StatusCode) or objPing.StatusCode <> 0 Then
                outStatus = "OFFLINE"
            Else
                outStatus = "ONLINE"
                outResponseTime = objPing.ResponseTime
            End If
        Next
    End If
    On Error GoTo 0
    
    Set colPings = Nothing
    Set objWMIService = Nothing
End Function
%>