<%
' Authentication Check
If Session("loggedin") <> True Then
    Response.Redirect "login.asp"
End If
%>
