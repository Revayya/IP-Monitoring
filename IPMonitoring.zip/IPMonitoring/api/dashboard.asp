<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Call OpenDB()

Dim total, online, offline, avg_time, monitoring_active
total = 0
online = 0
offline = 0
avg_time = 0
monitoring_active = False

' Get counts
Dim rs
Set rs = objConn.Execute("SELECT COUNT(*) AS c FROM devices WHERE is_active = 1")
If Not rs.EOF Then total = rs("c")
rs.Close

Set rs = objConn.Execute("SELECT COUNT(*) AS c FROM devices WHERE is_active = 1 AND status = 'ONLINE'")
If Not rs.EOF Then online = rs("c")
rs.Close

Set rs = objConn.Execute("SELECT COUNT(*) AS c FROM devices WHERE is_active = 1 AND status = 'OFFLINE'")
If Not rs.EOF Then offline = rs("c")
rs.Close

Set rs = objConn.Execute("SELECT AVG(last_response_time) AS a FROM devices WHERE is_active = 1 AND status = 'ONLINE' AND last_response_time IS NOT NULL")
If Not rs.EOF And Not IsNull(rs("a")) Then avg_time = Round(rs("a"), 2)
rs.Close

' Get settings
Set rs = objConn.Execute("SELECT setting_value FROM settings WHERE setting_key = 'monitoring_enabled'")
If Not rs.EOF Then
    If rs("setting_value") = "1" Then monitoring_active = True
End If
rs.Close

' Build JSON
Dim jsonStr
jsonStr = "{"
jsonStr = jsonStr & """total_devices"": " & total & ","
jsonStr = jsonStr & """online_devices"": " & online & ","
jsonStr = jsonStr & """offline_devices"": " & offline & ","
jsonStr = jsonStr & """avg_response_time"": " & avg_time & ","
jsonStr = jsonStr & """monitoring_active"": " & LCase(CStr(monitoring_active)) & ","

' Latest events
jsonStr = jsonStr & """latest_events"": ["
Set rs = objConn.Execute("SELECT l.id, d.name, d.ip_address, l.status, l.response_time, l.ping_time FROM ping_logs l JOIN devices d ON l.device_id = d.id ORDER BY l.ping_time DESC LIMIT 5")

Dim isFirst
isFirst = True
Do While Not rs.EOF
    If Not isFirst Then jsonStr = jsonStr & ","
    jsonStr = jsonStr & "{"
    jsonStr = jsonStr & """device_name"": """ & EscapeJSONString(rs("name")) & ""","
    jsonStr = jsonStr & """ip_address"": """ & EscapeJSONString(rs("ip_address")) & ""","
    jsonStr = jsonStr & """status"": """ & EscapeJSONString(rs("status")) & ""","
    If IsNull(rs("response_time")) Then
        jsonStr = jsonStr & """response_time"": null,"
    Else
        jsonStr = jsonStr & """response_time"": " & rs("response_time") & ","
    End If
    jsonStr = jsonStr & """ping_time"": """ & EscapeJSONString(rs("ping_time")) & """"
    jsonStr = jsonStr & "}"
    isFirst = False
    rs.MoveNext
Loop
rs.Close

jsonStr = jsonStr & "]}"
Response.Write(jsonStr)

Call CloseDB()
%>
