<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/functions.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Dim postData, regEx, matches
postData = GetPostData()

Call OpenDB()

' Basic parsing of JSON using regex for settings (e.g. ping_interval, timeout)
' This is simplified for Classic ASP limits
Dim settingsKeys, i, key, val, cmd
settingsKeys = Array("ping_interval", "timeout", "retry_count", "offline_threshold", "max_devices_per_cycle", "log_retention_days")

Set regEx = New RegExp
regEx.IgnoreCase = True

For i = 0 To UBound(settingsKeys)
    key = settingsKeys(i)
    regEx.Pattern = """" & key & """\s*:\s*""?([^""},]+)""?"
    If regEx.Test(postData) Then
        Set matches = regEx.Execute(postData)
        val = Trim(matches(0).SubMatches(0))
        
        Set cmd = Server.CreateObject("ADODB.Command")
        cmd.ActiveConnection = objConn
        cmd.CommandText = "UPDATE settings SET setting_value = ? WHERE setting_key = ?"
        cmd.Parameters.Append cmd.CreateParameter("@val", 200, 1, 255, val)
        cmd.Parameters.Append cmd.CreateParameter("@key", 200, 1, 50, key)
        cmd.Execute
        Set cmd = Nothing
    End If
Next

Call CloseDB()

Response.Write("{""success"": true, ""message"": ""Settings saved successfully""}")
%>
