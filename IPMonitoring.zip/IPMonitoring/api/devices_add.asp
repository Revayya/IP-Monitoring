<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/functions.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Dim postData, regEx, matches, devName, devIp
postData = GetPostData()

Set regEx = New RegExp
regEx.IgnoreCase = True
regEx.Global = True

' Basic extract for name
regEx.Pattern = """name""\s*:\s*""([^""]+)"""
If regEx.Test(postData) Then
    Set matches = regEx.Execute(postData)
    devName = matches(0).SubMatches(0)
End If

' Basic extract for ip_address
regEx.Pattern = """ip_address""\s*:\s*""([^""]+)"""
If regEx.Test(postData) Then
    Set matches = regEx.Execute(postData)
    devIp = matches(0).SubMatches(0)
End If

If devName = "" Or devIp = "" Then
    Response.Write("{""success"": false, ""message"": ""Missing name or IP""}")
    Response.End
End If

If Not IsValidIP(devIp) Then
    Response.Write("{""success"": false, ""message"": ""Invalid IP Address""}")
    Response.End
End If

Call OpenDB()

' Check existing
Dim rs
Set rs = Server.CreateObject("ADODB.Recordset")
rs.Open "SELECT id FROM devices WHERE ip_address = '" & SanitizeInput(devIp) & "'", objConn

If Not rs.EOF Then
    rs.Close
    Call CloseDB()
    Response.Write("{""success"": false, ""message"": ""IP already exists""}")
    Response.End
End If
rs.Close

Dim cmd
Set cmd = Server.CreateObject("ADODB.Command")
cmd.ActiveConnection = objConn
cmd.CommandText = "INSERT INTO devices (name, ip_address, status) VALUES (?, ?, 'UNKNOWN')"
cmd.Parameters.Append cmd.CreateParameter("@name", 200, 1, 100, devName)
cmd.Parameters.Append cmd.CreateParameter("@ip", 200, 1, 50, devIp)

On Error Resume Next
cmd.Execute
If Err.Number <> 0 Then
    Response.Write("{""success"": false, ""message"": ""Database error""}")
Else
    Response.Write("{""success"": true}")
End If
On Error GoTo 0

Call CloseDB()
%>
