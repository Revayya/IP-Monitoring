<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Call OpenDB()
objConn.Execute "UPDATE settings SET setting_value = '0' WHERE setting_key = 'monitoring_enabled'"
Call CloseDB()

Response.Write("{""success"": true, ""message"": ""Monitoring stopped""}")
%>
