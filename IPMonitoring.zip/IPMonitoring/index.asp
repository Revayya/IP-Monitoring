<!--#include virtual="/IPMonitoring/includes/auth.asp"-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css?v=2">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <div class="sidebar">
        <h2>IP Monitor</h2>
        <ul>
            <li><a href="#" onclick="showView('dashboard')" id="nav-dashboard" class="active">Dashboard</a></li>
            <li><a href="#" onclick="showView('devices')" id="nav-devices">Devices</a></li>
            <li><a href="#" onclick="showView('logs')" id="nav-logs">Logs</a></li>
            <li><a href="#" onclick="showView('settings')" id="nav-settings">Settings</a></li>
            <li style="margin-top: 30px;"><a href="logout.asp" style="background-color: #e74c3c; text-align: center;">Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <header>
            <div class="header-left">
                <h1>Dashboard</h1>
            </div>
            <div class="header-right">
                <span id="monitoring-status-indicator" class="status-badge offline">STOPPED</span>
                <button id="btn-start-monitoring" class="btn btn-success" onclick="startMonitoring()">START PING ALL</button>
                <button id="btn-stop-monitoring" class="btn btn-danger" onclick="stopMonitoring()" style="display:none;">STOP PING</button>
            </div>
        </header>
        
        <div id="view-dashboard" class="view active">
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Devices</h3>
                    <p id="stat-total">0</p>
                </div>
                <div class="stat-card">
                    <h3>Online</h3>
                    <p id="stat-online" class="text-success">0</p>
                </div>
                <div class="stat-card">
                    <h3>Offline</h3>
                    <p id="stat-offline" class="text-danger">0</p>
                </div>
                <div class="stat-card">
                    <h3>Avg Response</h3>
                    <p id="stat-avg-time">0 ms</p>
                </div>
            </div>
            
            <div class="panel">
                <h3>Latest Events</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Device</th>
                            <th>IP Address</th>
                            <th>Status</th>
                            <th>Response Time</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody id="latest-events-body">
                        <!-- Populated by JS -->
                    </tbody>
                </table>
            </div>
        </div>

        <div id="view-devices" class="view">
            <div class="panel">
                <div class="panel-header" style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                    <h3 style="margin:0; flex-grow:1;">Device Management</h3>
                    <input type="text" id="device-search" class="form-control" placeholder="Search Name or IP..." style="max-width:200px; padding:6px;" onkeyup="filterDevices()">
                    <select id="device-filter" class="form-control" style="padding:6px;" onchange="filterDevices()">
                        <option value="ALL">All Status</option>
                        <option value="ONLINE">Online Only</option>
                        <option value="OFFLINE">Offline Only</option>
                        <option value="UNKNOWN">Unknown Only</option>
                    </select>
                    <button class="btn btn-primary" onclick="showAddDeviceModal()">Add Device</button>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>IP Address</th>
                            <th>Status</th>
                            <th>Last Checked</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="devices-body">
                        <!-- Populated by JS -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Add Modal/Other views here... -->
        
        <div id="view-logs" class="view">
            <div class="panel">
                <div class="panel-header">
                    <h3>Ping Logs</h3>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Device Name</th>
                            <th>IP Address</th>
                            <th>Status</th>
                            <th>Response Time</th>
                            <th>Ping Time</th>
                        </tr>
                    </thead>
                    <tbody id="logs-body">
                        <!-- Populated dynamically if you create a logs.js -->
                        <tr><td colspan="5">Use the dashboard for latest events. Full logs view coming soon.</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="view-settings" class="view">
            <div class="panel" style="max-width: 600px; margin: 0 auto;">
                <div class="panel-header">
                    <h3>System Settings</h3>
                </div>
                <form id="settings-form" onsubmit="saveSettings(event)">
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Ping Interval (seconds)</label>
                        <input type="number" id="ping_interval" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Timeout (ms)</label>
                        <input type="number" id="timeout" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Retry Count</label>
                        <input type="number" id="retry_count" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Offline Threshold (fails before marked offline)</label>
                        <input type="number" id="offline_threshold" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; margin-bottom:5px;">Max Devices Per Cycle</label>
                        <input type="number" id="max_devices_per_cycle" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <label style="display:block; margin-bottom:5px;">Log Retention (Days)</label>
                        <input type="number" id="log_retention_days" class="form-control" style="width:100%; padding:8px;" required>
                    </div>
                    <button type="submit" class="btn btn-success" style="width:100%">Save Settings</button>
                </form>
            </div>
        </div>
        
    </div>

    <script src="js/api.js?v=2"></script>
    <script src="js/dashboard.js"></script>
    <script src="js/devices.js?v=3"></script>
    <script src="js/settings.js"></script>
    <script src="js/logs.js"></script>
    <script>
        function showView(viewId) {
            document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
            document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
            
            document.getElementById('view-' + viewId).classList.add('active');
            document.getElementById('nav-' + viewId).classList.add('active');
            document.querySelector('header h1').innerText = viewId.charAt(0).toUpperCase() + viewId.slice(1);
            
            if(viewId === 'devices') loadDevices();
            if(viewId === 'settings') loadSettings();
            if(viewId === 'logs') loadLogs();
        }
    </script>
</body>
</html>
