# IP Monitoring System

A Classic ASP-based IP monitoring system designed for a Windows IIS server environment.

## Technologies Used
- **Backend:** Classic ASP (.asp), VBScript
- **Database:** MySQL, MySQL ODBC 5.1 Driver
- **Frontend:** HTML5, CSS3, Vanilla JavaScript, Fetch API

## Setup Instructions

1. **Database:**
   - Import `/database/database.sql` into your MySQL instance using SQLyog or another tool.
   - Configure the MySQL ODBC 5.1 Driver on the Windows IIS Server.

2. **IIS Configuration:**
   - Create a site or virtual directory in IIS pointing to the `IPMonitoring` folder.
   - Ensure ASP is enabled in IIS features (CGI/ISAPI).
   - Ensure the Application Pool has sufficient permissions to run `WScript.Shell` (ping).

3. **Application Configuration:**
   - Edit `/includes/config.asp` and set your `DB_SERVER`, `DB_NAME`, `DB_USER`, and `DB_PASS`.

4. **Background Monitoring (Important):**
   - The application supports continuous background monitoring.
   - Set up a **Windows Scheduled Task** to run `admin/worker.vbs` every 1 minute.
   - Update the URL inside `worker.vbs` to point to the correct absolute URL for `worker_ping_cycle.asp` on your server.
   - This ensures continuous monitoring independent of the browser session.

## Architecture

- **Dashboard:** Uses AJAX polling to keep statistics and events up-to-date without page reloads.
- **Single-ping:** Executes an immediate server-side ping via the shell and returns the result via JSON.
- **Security:** All SQL queries use ADODB parameters to prevent SQL injection.
